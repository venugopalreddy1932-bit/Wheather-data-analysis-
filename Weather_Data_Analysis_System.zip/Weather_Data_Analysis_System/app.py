from flask import Flask, render_template, request, redirect, url_for, flash
import pandas as pd
import numpy as np
import mysql.connector
from mysql.connector import Error
from pathlib import Path
from datetime import datetime
import os

from analysis import analyze_weather, validate_weather_data
from database import save_valid_records, fetch_weather_records

app = Flask(__name__)
app.secret_key = "weather-analysis-secret"
UPLOAD_DIR = Path("data")
UPLOAD_DIR.mkdir(exist_ok=True)

@app.route("/", methods=["GET", "POST"])
def index():
    result = None
    if request.method == "POST":
        file = request.files.get("weather_file")
        if not file or not file.filename.lower().endswith(".csv"):
            flash("Please upload a CSV file.")
            return redirect(url_for("index"))
        path = UPLOAD_DIR / "uploaded_weather.csv"
        file.save(path)
        try:
            df = pd.read_csv(path)
            result = validate_weather_data(df)
            result["analysis"] = analyze_weather(result["valid_data"])
            try:
                result["db_message"] = save_valid_records(result["valid_data"])
            except Exception as e:
                result["db_message"] = f"MySQL not saved: {e}"
        except Exception as e:
            flash(f"Could not process file: {e}")
    return render_template("index.html", result=result)

@app.route("/dashboard")
def dashboard():
    try:
        df = fetch_weather_records()
        if df.empty:
            return render_template("dashboard.html", result=None, message="No records found in MySQL.")
        result = analyze_weather(df)
        return render_template("dashboard.html", result=result)
    except Exception as e:
        return render_template("dashboard.html", result=None, message=str(e))

if __name__ == "__main__":
    app.run(debug=True)
