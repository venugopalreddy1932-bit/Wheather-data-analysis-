# Weather Data Analysis System Using Python

## Objective
Explore recorded weather observations and summarize temperature, humidity and rainfall patterns over time. This system does not forecast weather.

## Features
- Upload a weather CSV
- Validate date, location, temperature, humidity and rainfall
- Handle missing/invalid values transparently
- Store valid records in MySQL
- Calculate daily/monthly min, max and average values
- Compare rainfall and temperature by month
- Interactive dashboard charts
- Data-quality report

## Units
- Temperature: degrees Celsius (°C)
- Humidity: percentage (%)
- Rainfall: millimetres (mm)
- Date: YYYY-MM-DD

## CSV format
```csv
observation_date,location,temperature,humidity,rainfall
2026-01-01,Tirupati,27.5,65,2.4
```

## Setup
1. Install Python 3.
2. Create a MySQL database by running `schema.sql`.
3. Install dependencies:
   `pip install -r requirements.txt`
4. Set MySQL environment variables if needed:
   - MYSQL_HOST
   - MYSQL_USER
   - MYSQL_PASSWORD
   - MYSQL_DATABASE
5. Run:
   `python app.py`
6. Open the local Flask address shown in the terminal.

## Notes
The sample CSV is supplied for testing. Uploading a new CSV replaces the temporary uploaded file but does not automatically delete old MySQL rows. Use SQL `TRUNCATE TABLE weather_records;` before a fresh database run if required.
