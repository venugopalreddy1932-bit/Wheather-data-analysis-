import pandas as pd
import numpy as np

REQUIRED = ["observation_date", "location", "temperature", "humidity", "rainfall"]

def validate_weather_data(df):
    df = df.copy()
    missing_columns = [c for c in REQUIRED if c not in df.columns]
    if missing_columns:
        raise ValueError("Missing required columns: " + ", ".join(missing_columns))

    df["observation_date"] = pd.to_datetime(df["observation_date"], errors="coerce")
    for col in ["temperature", "humidity", "rainfall"]:
        df[col] = pd.to_numeric(df[col], errors="coerce")

    invalid_date = df["observation_date"].isna()
    missing_temp = df["temperature"].isna()
    missing_humidity = df["humidity"].isna()
    missing_rainfall = df["rainfall"].isna()
    invalid_humidity_range = df["humidity"].notna() & ~df["humidity"].between(0, 100)
    invalid_rainfall = df["rainfall"].notna() & (df["rainfall"] < 0)
    invalid_location = df["location"].isna() | (df["location"].astype(str).str.strip() == "")

    invalid = (invalid_date | missing_temp | missing_humidity | missing_rainfall |
               invalid_humidity_range | invalid_rainfall | invalid_location)

    valid = df.loc[~invalid, REQUIRED].copy()
    valid["observation_date"] = valid["observation_date"].dt.strftime("%Y-%m-%d")

    quality = {
        "total": len(df),
        "valid": len(valid),
        "invalid": int(invalid.sum()),
        "invalid_dates": int(invalid_date.sum()),
        "missing_temperature": int(missing_temp.sum()),
        "missing_humidity": int(missing_humidity.sum()),
        "missing_rainfall": int(missing_rainfall.sum()),
        "invalid_humidity_range": int(invalid_humidity_range.sum()),
        "invalid_rainfall": int(invalid_rainfall.sum()),
        "invalid_location": int(invalid_location.sum()),
    }
    return {"valid_data": valid, "quality": quality}

def analyze_weather(df):
    if df is None or df.empty:
        return {"daily": [], "monthly": [], "temperature_chart": {}, "rainfall_chart": {}, "meta": {}}
    x = df.copy()
    x["observation_date"] = pd.to_datetime(x["observation_date"])
    for c in ["temperature", "humidity", "rainfall"]:
        x[c] = pd.to_numeric(x[c], errors="coerce")
    x["month"] = x["observation_date"].dt.to_period("M").astype(str)

    daily = x.groupby(["observation_date", "location"]).agg(
        temperature_min=("temperature","min"),
        temperature_max=("temperature","max"),
        temperature_avg=("temperature","mean"),
        humidity_min=("humidity","min"),
        humidity_max=("humidity","max"),
        humidity_avg=("humidity","mean"),
        rainfall_total=("rainfall","sum")
    ).reset_index()
    monthly = x.groupby(["month", "location"]).agg(
        temperature_min=("temperature","min"),
        temperature_max=("temperature","max"),
        temperature_avg=("temperature","mean"),
        humidity_avg=("humidity","mean"),
        rainfall_total=("rainfall","sum"),
        rainfall_avg=("rainfall","mean")
    ).reset_index()

    locations = sorted(x["location"].dropna().unique().tolist())
    months = sorted(x["month"].unique().tolist())
    temp_series = []
    rain_series = []
    for loc in locations:
        m = monthly[monthly.location == loc]
        temp_series.append({"name": loc, "values": [round(float(m.loc[m.month==mo, "temperature_avg"].iloc[0]),2) if not m.loc[m.month==mo].empty else None for mo in months]})
        rain_series.append({"name": loc, "values": [round(float(m.loc[m.month==mo, "rainfall_total"].iloc[0]),2) if not m.loc[m.month==mo].empty else None for mo in months]})

    def records(frame):
        out=[]
        for r in frame.to_dict("records"):
            out.append({k: (v.strftime("%Y-%m-%d") if hasattr(v, "strftime") else (round(float(v),2) if isinstance(v,(np.floating,float)) else v)) for k,v in r.items()})
        return out

    return {
        "daily": records(daily.tail(100)),
        "monthly": records(monthly),
        "temperature_chart": {"labels": months, "series": temp_series},
        "rainfall_chart": {"labels": months, "series": rain_series},
        "meta": {
            "locations": locations,
            "start": x["observation_date"].min().strftime("%Y-%m-%d"),
            "end": x["observation_date"].max().strftime("%Y-%m-%d"),
            "records": len(x)
        }
    }
