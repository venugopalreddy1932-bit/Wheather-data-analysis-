CREATE DATABASE IF NOT EXISTS weather_analysis;
USE weather_analysis;

CREATE TABLE IF NOT EXISTS weather_records (
    record_id INT AUTO_INCREMENT PRIMARY KEY,
    observation_date DATE NOT NULL,
    location VARCHAR(100) NOT NULL,
    temperature DECIMAL(6,2),
    humidity DECIMAL(5,2),
    rainfall DECIMAL(8,2),
    INDEX idx_date (observation_date),
    INDEX idx_location (location)
);
