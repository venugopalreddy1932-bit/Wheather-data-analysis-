import os
import pandas as pd
import mysql.connector
from mysql.connector import Error

DB_CONFIG = {
    "host": os.getenv("MYSQL_HOST", "localhost"),
    "user": os.getenv("MYSQL_USER", "root"),
    "password": os.getenv("MYSQL_PASSWORD", ""),
    "database": os.getenv("MYSQL_DATABASE", "weather_analysis")
}

def get_connection():
    return mysql.connector.connect(**DB_CONFIG)

def save_valid_records(df):
    if df.empty:
        return "No valid records to save."
    conn = get_connection()
    cur = conn.cursor()
    sql = """INSERT INTO weather_records
             (observation_date, location, temperature, humidity, rainfall)
             VALUES (%s, %s, %s, %s, %s)"""
    values = [tuple(x) for x in df[["observation_date","location","temperature","humidity","rainfall"]].to_numpy()]
    cur.executemany(sql, values)
    conn.commit()
    count = cur.rowcount
    cur.close(); conn.close()
    return f"{count} valid records saved to MySQL."

def fetch_weather_records():
    conn = get_connection()
    df = pd.read_sql("SELECT observation_date, location, temperature, humidity, rainfall FROM weather_records", conn)
    conn.close()
    return df
